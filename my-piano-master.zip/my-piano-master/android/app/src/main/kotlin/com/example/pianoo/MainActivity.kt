package com.example.pianoo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
